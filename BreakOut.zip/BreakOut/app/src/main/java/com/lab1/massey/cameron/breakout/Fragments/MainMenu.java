package com.lab1.massey.cameron.breakout.Fragments;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.lab1.massey.cameron.breakout.R;

public class MainMenu extends Fragment {

    private OnUpdate mListener;

    public MainMenu() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main_menu, container, false);

        Button button = (Button)view.findViewById(R.id.settings_button);
        Button button1 = (Button)view.findViewById(R.id.start_button);
        Button button2 = (Button)view.findViewById(R.id.how_button);

        button.setTag("settings");
        button1.setTag("start");
        button2.setTag("how");


        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onFragmentInteraction((String)v.getTag());
                }

            }
        };

        button.setOnClickListener(onClickListener);
        button1.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener);


        return view;
    }

    @Override
    public void onAttach(Activity context) {
        super.onAttach(context);
        if (context instanceof OnUpdate) {
            mListener = (OnUpdate) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnUpdate");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnUpdate {
        // TODO: Update argument type and name
        void onFragmentInteraction(String string);
    }
}
