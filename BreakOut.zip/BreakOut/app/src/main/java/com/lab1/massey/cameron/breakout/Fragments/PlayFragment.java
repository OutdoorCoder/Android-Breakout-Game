package com.lab1.massey.cameron.breakout.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lab1.massey.cameron.breakout.GraphicStuff.PlayScreen;
import com.lab1.massey.cameron.breakout.R;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PlayFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class PlayFragment extends Fragment implements PlayScreen.eventListener {

    private OnFragmentInteractionListener mListener;
    private TextView balls;
    private TextView levels;
    private TextView score;
    private TextView bricks;
    private final String BALL_KEY = "ball";
    private final String BRICK_KEY = "brick";
    private final String LEVEL_KEY = "level";
    private final String SCORE_KEY = "score";
    private PlayScreen playScreen;

    public PlayFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_play, container, false);
        SharedPreferences sharedPreferences = findPrefs();
        updateText(view, sharedPreferences);
        //balls.setText(R);
        playScreen = (PlayScreen)view.findViewById(R.id.playScreen);
        playScreen.setEventListener(this);

        return view;
    }



    //TODO fix this shit, its resetting the entire view.
    @Override
    public void onEventAccured(String s, int i) {
        if(s.equals(BALL_KEY) && isAdded()){
            balls.setText(getResources().getString(R.string.balls) + i);
        }
        else if(s.equals(BRICK_KEY)&& isAdded()){
            bricks.setText(getResources().getString(R.string.bricks) + i);
        }
        else if(s.equals(LEVEL_KEY)&& isAdded()){
            levels.setText(getResources().getString(R.string.levels) + i);
        }
        else if(s.equals(SCORE_KEY)&& isAdded()){
            score.setText(getResources().getString(R.string.score) + i);
        }
    }

    public void updateText(View view, SharedPreferences sharedPreferences){
         balls = (TextView)view.findViewById(R.id.balls);
         levels = (TextView)view.findViewById(R.id.levels);
         score = (TextView)view.findViewById(R.id.score);
         bricks = (TextView)view.findViewById(R.id.bricks);

        balls.setText(getResources().getString(R.string.balls) + sharedPreferences.getInt("balls_per_level", 3));
        bricks.setText(getResources().getString(R.string.bricks) + sharedPreferences.getInt("initial_brick_count", 5));
        levels.setText(getResources().getString(R.string.levels) + 1);
        score.setText(getResources().getString(R.string.score) + 0);


    }

    public SharedPreferences findPrefs(){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.getActivity());
        return sharedPreferences;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onPause() {
        playScreen.onPause();
        super.onPause();
    }

    @Override
    public void onResume() {
        playScreen.onResume();
        super.onResume();
    }
}
