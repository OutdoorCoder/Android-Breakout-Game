package com.lab1.massey.cameron.breakout.Fragments;


import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lab1.massey.cameron.breakout.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class SettingsFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {



    public SettingsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().
                unregisterOnSharedPreferenceChangeListener(this) ;
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().
                registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        Integer value = sharedPreferences.getInt(key, 0);

        Preference pref;
        if(key.equalsIgnoreCase("initial_brick_count") && value != 0){
            pref =  findPreference(key);
            pref.setSummary(String.valueOf(value));
        }
        else if(key.equalsIgnoreCase("hits_to_remove_brick") && value != 0){

            pref =  findPreference(key);
            pref.setSummary(String.valueOf(value));
        }
        else if(key.equalsIgnoreCase("balls_per_level") && value != 0){

            pref =  findPreference(key);
            pref.setSummary(String.valueOf(value));
        }
        else if(key.equalsIgnoreCase("paddle_sensitivity") && value != 0) {
            pref =  findPreference(key);
            pref.setSummary(String.valueOf(value));
        }
        else if(key.equalsIgnoreCase("ball_speed") && value != 0) {
            pref =  findPreference(key);
            pref.setSummary(String.valueOf(value));
        }

    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.action_settings).setVisible(false);
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        addPreferencesFromResource(R.xml.preferences);
        SharedPreferences sharedPreferences = getPreferenceScreen().getSharedPreferences();
        onSharedPreferenceChanged(sharedPreferences,"initial_brick_count");
        onSharedPreferenceChanged(sharedPreferences, "hits_to_remove_brick");
        onSharedPreferenceChanged(sharedPreferences, "balls_per_level");
        onSharedPreferenceChanged(sharedPreferences, "paddle_sensitivity");
        onSharedPreferenceChanged(sharedPreferences, "ball_speed");
    }


}
