package com.lab1.massey.cameron.breakout.GraphicStuff;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Toast;

import com.lab1.massey.cameron.breakout.R;

import java.util.Arrays;
import java.util.Random;


/**
 * Created by Cameron on 2/28/2016.
 */
public class PlayScreen extends View {

    private final int TIMER_MESC = 30;
    final private int LEFT = 0;
    private int top = 100;
    private int right = 0;
    private int bottom;
    private int brickWidth;
    private int brickHeight;
    private int circleRadius;
    private Paint circlePaint;
    private int width, height;
    private int ballsLeft;
    private int [][] points;
    private double xPos, yPos;
    private double xVel, yVel;
    private double paddleXVel, paddleLeft, paddleRight;

    Handler clockHandler ;
    Runnable clockTimer ;
    private boolean alive;
    SharedPreferences prefs;
    private eventListener mEventListener;
    private final String BALL_KEY = "ball";
    private final String BRICK_KEY = "brick";
    private final String LEVEL_KEY = "level";
    private final String SCORE_KEY = "score";
    private int bricksLeft, numBricks;
    private int level;
    private int row, col;
    private int brickHealth;
    private int score;
    private boolean first;
    private boolean toggle;
    private MediaPlayer mp;
    private MediaPlayer wilhelm;
    private MediaPlayer gameOver;
    private MediaPlayer yeah;



    public void init(){


        circleRadius = 10;
        circlePaint = new Paint();
        circlePaint.setColor(Color.BLUE);

        paddleXVel = 0;
        alive = true;
        prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
        level = 1;
        xVel = -1* prefs.getInt("ball_speed", 5);
        yVel = -1* prefs.getInt("ball_speed", 5);
        first = true;
        toggle = false;
        mp = MediaPlayer.create(getContext(), R.raw.pong);
        wilhelm = MediaPlayer.create(getContext(), R.raw.wilhelm);
        gameOver = MediaPlayer.create(getContext(), R.raw.game_over);
        yeah = MediaPlayer.create(getContext(), R.raw.yeah);

        brickHealth = prefs.getInt("hits_to_remove_brick", 4);
        ballsLeft = prefs.getInt("balls_per_level", 4);
        score = 0;
        row = 10;
        col = 10;
        points = new int[row][col];
        for(int[] x: points) {
            Arrays.fill(x, 0);
        }
        randomFill(0);





        //timer
        clockHandler = new Handler();
        clockTimer = new Runnable() {
            @Override
            public void run() {
                updatePhysics();
                invalidate();
                clockHandler.postDelayed(this, TIMER_MESC);
            }
        };

        //start timer
       // clockHandler.postDelayed(clockTimer, TIMER_MESC);

        //checks when the screen is viewable by the user, best way to get heigh and width before ondraw()
        this.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                width = getWidth();
                height = getHeight();

                if(first == true){
                    xPos = width / 2;
                    yPos = height - circleRadius * 10;
                    paddleLeft = width /2 - width / 10;
                    paddleRight = width /2 + width / 10;
                    first = false;
                }
            }
        });

        //listener to detect where user is touching the screen
        this.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                int speed = prefs.getInt("paddle_sensitivity", 10);
                if(action == MotionEvent.ACTION_DOWN){
                    float y = event.getY();
                    float x = event.getX();
                    if(y < getHeight() / 2 && toggle == false){
                        toggle = true;
                        onPause();
                        return true;
                    }
                    else if(y < getHeight() / 2 && toggle == true){
                        toggle = false;
                        onResume();
                        return true;
                    }
                    if( x < width / 2){
                        paddleXVel = -1 * speed;
                        return true;
                    }
                    else {
                        paddleXVel = 1 * speed;

                    }
                    return  true;
                }
                else if(action == MotionEvent.ACTION_UP){
                    paddleXVel = 0;
                    return true;
                }



                return false;


            }
        });

    }

    public PlayScreen(Context context) {

        super(context);

        init();
    }

    public PlayScreen(Context context, AttributeSet attrs) {

        super(context, attrs);
        init();
    }

    public PlayScreen(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public interface eventListener {
        public void onEventAccured(String s, int i);
    }

    public void setEventListener(eventListener mEventListener) {
        this.mEventListener = mEventListener;
    }

    public void randomFill(int i){
        Random random = new Random();
        if(i == 0) {
            i = prefs.getInt("initial_brick_count", 50);
        }
        bricksLeft = i;
        numBricks = bricksLeft;

        while(i != 0){
            int x = random.nextInt(row);
            int y = random.nextInt(col);
            if(points[x][y] == 0) {
                points[x][y] = brickHealth;
                i --;
            }
        }
    }

    public void fillBricks(Canvas canvas){

        for(int i = 0; i < points.length; i++){
            for(int x = 0; x < points[i].length; x++){

                //fill array with bricks spaced properly
                if(points[i][x] != 0) {
                    Rect rect1 = new Rect(LEFT + (x * brickWidth), top + (i * brickHeight), brickWidth + (x * brickWidth), top + brickHeight + (i * brickHeight));
                    Paint paint = new Paint();
                    Paint border = new Paint();
                    border.setColor(getResources().getColor(R.color.black));
                    switch(points[i][x]){
                        case 4: paint.setColor(getResources().getColor(R.color.brickBlue));
                            break;
                        case 3: paint.setColor(getResources().getColor(R.color.brickRed));
                            break;
                        case 2: paint.setColor(getResources().getColor(R.color.brickYellow));
                            break;
                        case 1: paint.setColor(getResources().getColor(R.color.brickGreen));
                            break;
                        case 0: paint.setColor(getResources().getColor(R.color.white));
                            break;

                    }

                    paint.setStyle(Paint.Style.FILL);
                    border.setStyle(Paint.Style.STROKE);
                    canvas.drawRect(rect1, paint);
                    canvas.drawRect(rect1, border);


                }


            }
        }
    }


    @Override
    protected void onDraw(Canvas canvas) {


        right = getWidth();
        top = 0;
        bottom = height;
        brickWidth = getWidth() / 10;
        brickHeight = brickWidth / 2;

        canvas.drawColor(getResources().getColor(R.color.white));

        fillBricks(canvas);
        if(alive) {
            canvas.drawCircle((int)xPos, (int)yPos, circleRadius, circlePaint);
        }
        else{
            Toast.makeText(getContext(), "You have lost the game!", Toast.LENGTH_SHORT).show();
            clockHandler.removeCallbacks(clockTimer);
        }

        Rect paddle = new Rect((int)paddleLeft, (int)bottom - brickHeight / 2, (int)paddleRight, bottom );
        Paint black = new Paint(getResources().getColor(R.color.black));
        black.setStyle(Paint.Style.FILL);
        canvas.drawRect(paddle, black);
        //TODO make pause work

        super.onDraw(canvas);
    }



    public void updatePhysics() {
        xPos += xVel;
        yPos += yVel;


        paddleLeft += paddleXVel;
        paddleRight += paddleXVel;

        double pDifference = paddleRight - paddleLeft;


        if(paddleRight < 0){

            paddleLeft = right;
            paddleRight = paddleLeft + pDifference;
        }
        else if(paddleLeft > right){

            paddleRight = 0;
            paddleLeft = paddleRight - pDifference;
        }

        double circleTopX = xPos, circleTopY = yPos - circleRadius;
        double circleBottomX = xPos, circleBottomY = yPos + circleRadius;
        double circleRightX = xPos + circleRadius, circleRightY = yPos;
        double circleLeftX = xPos - circleRadius, circleLeftY = yPos;

        int r = (int)circleTopY / brickHeight;
        int c = (int)circleTopX / brickWidth;

        //check if it is hitting the paddle
        if(xPos > paddleLeft && xPos < paddleRight && circleBottomY > bottom - brickHeight / 2){
            mp.start();
            double x = (circleBottomX - (paddleLeft + ((paddleRight - paddleLeft) / 2))) / (paddleRight - paddleLeft) / 2;
            double angle = 67.5 * x;
            double radians = angle *(Math.PI / 180);
            double speed = Math.sqrt((Math.pow(xVel, 2) + Math.pow(yVel, 2)));
            xVel = (Math.sin(radians) * Math.abs(speed));
            yVel = (-1 * (Math.cos(radians)) * Math.abs(speed));
            return;
        }

        //check if the top is hitting
        if(r < row && c < col){
            if(points[r][c] != 0){
                mp.start();
                yVel *= -1;
                points[r][c]--;
                if(points[r][c] == 0){
                    bricksLeft--;
                    score += 1 * level;
                    callParent(SCORE_KEY, score);
                    callParent(BRICK_KEY, bricksLeft);

                }

                return;
            }
        }

        r  = (int)circleBottomY / brickHeight;
        c = (int)circleBottomX / brickWidth;
        //check if the bottom is hitting
        if(r < row && c < col){
            if(points[r][c] != 0){
                mp.start();
                yVel *= -1;
                points[r][c]--;
                if(points[r][c] == 0){
                    bricksLeft--;
                    score += 1 * level;
                    callParent(SCORE_KEY, score);
                    callParent(BRICK_KEY, bricksLeft);
                }
                return;
            }
        }

        r  = (int)circleRightY / brickHeight;
        c = (int)circleRightX / brickWidth;
        //check if the right is hitting
        if(r < row && c < col){
            if(points[r][c] != 0){
                mp.start();
                xVel *= -1;
                points[r][c]--;
                if(points[r][c] == 0){
                    bricksLeft--;
                    score += 1 * level;
                    callParent(SCORE_KEY, score);
                    callParent(BRICK_KEY, bricksLeft);
                }
                return;
            }
        }

        r  = (int)circleLeftY / brickHeight;
        c =(int) circleLeftX / brickWidth;
        //check if the left is hitting
        if(r < row && c < col){
            if(points[r][c] != 0){
                mp.start();
                xVel *= -1;
                points[r][c]--;
                if(points[r][c] == 0){
                    bricksLeft--;
                    score += 1 * level;
                    callParent(SCORE_KEY, score);
                    callParent(BRICK_KEY, bricksLeft);
                }
                return;
            }
        }



        //checks if the balls is hitting a wall
        if (yPos - circleRadius < 0 || yPos + circleRadius > height) {

            if (yPos - circleRadius < 0) {
                mp.start();
                yPos = circleRadius;
            } else {

                ballsLeft--;
                if(ballsLeft > 0){
                    wilhelm.start();
                    reset();
                    callParent(BALL_KEY, ballsLeft);

                    return;
                }
                else {
                    gameOver.start();
                    yPos = height + 5 * circleRadius;
                    alive = false;
                    xVel = 0;
                    yVel = 0;
                    callParent(BALL_KEY, ballsLeft);
                    return;
                }


            }
            yVel *= -1;
        }
        if (xPos - circleRadius < 0 || xPos + circleRadius > width) {
            mp.start();
            if (xPos - circleRadius < 0) {
                xPos = circleRadius;
            } else {
                xPos = width - circleRadius;
            }
            xVel *= -1;
        }

        checkWin();
    }

    public void checkWin(){
        if(alive && bricksLeft == 0){
            level++;
            yeah.start();
            //increase brickhealth every 5 levels for now
            if(level % 5 == 0 && brickHealth != 4){
                brickHealth++;
            }

            reset();
            if(numBricks < 100) {
                randomFill(numBricks + 1);
            }
            else {
                randomFill(numBricks);
            }
            callParent(BALL_KEY, ballsLeft);
            callParent(LEVEL_KEY, level);
            callParent(BRICK_KEY, bricksLeft);

            xVel += xVel * .33;
            yVel += yVel * .33;
        }
    }

    public void reset(){
        xVel *= -1;
        yVel *= -1;
        xPos = width / 2;
        yPos = height - circleRadius * 10;
        paddleLeft = width /2 - width / 10;
        paddleRight = width /2 + width / 10;
        paddleXVel = 0;
//TODO add sound effects for everything

    }




    protected void callParent(String s, int i) {

    /*
     * Some Code which the function doing //more code...
     */

        if (mEventListener != null) {
            mEventListener.onEventAccured(s, i);
        }
    }



    public void onPause(){
        if(clockHandler != null)
            clockHandler.removeCallbacks(clockTimer);
    }
    public void onResume(){
        if(clockHandler != null && toggle == false){
            clockHandler.postDelayed(clockTimer, TIMER_MESC);
        }
    }

    @Override
    public Parcelable onSaveInstanceState()
    {
        Bundle bundle = new Bundle();
        bundle.putParcelable("superState", super.onSaveInstanceState());
        bundle.putDouble("xPos", this.xPos);
        bundle.putDouble("yPos", this.yPos);
        bundle.putDouble("xVel", this.xVel);
        bundle.putDouble("yVel", this.yVel);
        return bundle;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state)
    {
        if (state instanceof Bundle) // implicit null check
        {
            Bundle bundle = (Bundle) state;
            this.xPos = bundle.getDouble("xPos");
            this.yPos = bundle.getDouble("yPos");
            this.xVel = bundle.getDouble("xVel");
            this.yVel = bundle.getDouble("yVel");
            state = bundle.getParcelable("superState");
        }
        super.onRestoreInstanceState(state);
    }

}





